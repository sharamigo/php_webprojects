$(document).ready(function() {

	$("#close_div").click(function() {
		$("#file_rename").css("display", "none");
	});
});